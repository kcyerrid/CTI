---
entity_type: pir
title: ""
pir_id: ""
status: draft
priority: high
classification: internal-only
category: strategic
focus_area: []
primary_question: ""
sub_questions: []
stakeholders: []
owner: ""
consumers: []
business_drivers: []
risk_themes: []
time_horizon: ongoing
review_cadence: quarterly
required_outputs: []
success_criteria: []
collection_topics: []
collection_sources: []
collection_methods: []
collection_constraints: []
data_sources_internal: []
data_sources_external: []
related_threat_actors: []
related_campaigns: []
related_malware: []
related_technologies: []
related_business_units: []
metrics: []
last_evaluated: ""
last_evaluated_by: ""
notes: []
created: "{{date}}"
updated: "{{date}}"
banner: 99_Attachments/CIPHER Obsidian Banner.png
banner-height: 300
content-start: 301
---

# {{title}}  
*{{pir_id}} — {{status}} — {{priority}} priority*

---

## 1. Primary Intelligence Question

**Primary Question**  
> {{primary_question}}

**Sub-Questions**  
- 

Use this section to phrase the PIR as a clear, decision-focused question (or set of questions) that intelligence will answer.

---

## 2. Business Context & Rationale

**Business Drivers**  
- 

**Risk Themes**  
- 

Describe why this PIR exists, what business problems or risks it is addressing, and how it ties to organizational objectives (e.g., fraud reduction, account takeover prevention, regulatory compliance).

---

## 3. Stakeholders, Owner, and Consumers

**Owner**  
- {{owner}}

**Primary Stakeholders**  
- 

**Intelligence Consumers**  
- 

Clarify who asked for this PIR, who is accountable for it, and which teams will use the resulting intelligence products (e.g., SOC, IR, Fraud, Legal, Executive leadership).

---

## 4. Scope, Focus, and Time Horizon

**Category**  
- {{category}}

**Focus Areas**  
- 

**Time Horizon**  
- {{time_horizon}}

**In Scope**  
- 

**Out of Scope**  
- 

Define the boundaries: what’s included, what’s specifically excluded, and the timeframe over which this PIR is relevant.

---

## 5. Required Intelligence Outputs

**Output Types**  
- Dashboards
- Alerts
- Weekly/Monthly briefings
- Investigative reports
- Hunt packages

**Success Criteria**  
- 

Describe what “good” looks like. What decisions should this PIR enable? What changes in detection, response, or risk posture are expected?

---

## 6. Collection Guidance

**Key Collection Topics**  
- 

**Collection Sources (Internal)**  
- 

**Collection Sources (External)**  
- 

**Collection Methods**  
- Automated collection
- Threat hunting
- Case-driven investigations
- OSINT/vendor research

**Constraints & Considerations**  
- 

Spell out what must be collected, from where, and how often, along with any legal, privacy, or technical constraints.

---

## 7. Data Sources & Telemetry

**Internal Data Sources**  
- SIEM tables  
- EDR telemetry  
- Identity/IAM logs  
- Email security logs  
- Application logs (e.g., mortgage LOS, servicing platforms)

**External Data Sources**  
- Commercial intel feeds  
- ISAC/industry sharing  
- Open-source intelligence  
- Vendor advisories  

Document the concrete data sets needed to answer this PIR reliably.

---

## 8. Related Intelligence Objects

**Threat Actors**  
- 

**Campaigns**  
- 

**Malware / Tooling**  
- 

**Technologies / Platforms**  
- 

**Business Units / Processes**  
- 

Use Obsidian links (e.g., `[[Threat Actors/Velvet Chollima]]`) to tie this PIR into your broader CTI graph.

---

## 9. Metrics & Evaluation

**Metrics / KPIs**  
- % of relevant incidents enriched with CTI for this PIR  
- Time to answer stakeholder questions  
- # of hunts or detections derived from this PIR  
- Reduction in specific loss types (e.g., fraud, ATO)

**Last Evaluated**  
- {{last_evaluated}} by {{last_evaluated_by}}

Explain how you’ll measure whether this PIR is still relevant, effective, and worth the ongoing collection and analysis effort.

---

## 10. Analyst Assessment

**Current Assessment**  
Summarize where things stand today with respect to this PIR: maturity, coverage, identified gaps, and current threat level.

**Analytic Confidence**  
- {{analytic_confidence}}

---

## 11. Intelligence Gaps & Collection Recommendations

**Intelligence Gaps**  
- 

**Collection Recommendations**  
- 

Capture what you *don’t* yet know and what new data, access, or tooling would materially improve your ability to answer this PIR.

---

## 12. Notes & Changelog

**Notes**  
- 

**Changelog**  
- {{created}} — Created  
- {{updated}} — Last updated  

