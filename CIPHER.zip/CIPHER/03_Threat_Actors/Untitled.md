---
entity_type: threat_actor
name:
type:
  - Nation-state
  - Criminal
  - Hacktivist
aliases:
country_of_origin:
attribution_confidence: Low | Moderate | High
primary_motive: []
secondary_motive: []
preferred_targets: []
associated_malware: []
associated_campaigns: []
associated_infrastructure: []
diamond_model:
  adversary: ""
  capability: ""
  infrastructure: ""
  victim: ""
primary_TTPs:
first_seen: ""
last_seen: ""
notable_incidents: []
risk_level:
  - 1 - Critical
  - 2 - High
  - 3 - Medium
  - 4 - Low
analyst_assessment: ""
analytic_confidence: low | moderate | high
priority_intelligence_requirements: []
tlp_classification:
  - TLP:RED
  - TLP:AMBER
  - TLP:GREEN
  - TLP:CLEAR
updated: YYYY-MM-DD
created: YYYY-MM-DD
author: []
banner: 99_Attachments/CIPHER Obsidian Banner.png
banner-height: 250
---

## **Summary**
A brief overview of who this threat actor is, what they are known for, and why they are relevant to loanDepot or Mortgage Banking.  
(2–4 sentences recommended)

---

## **Identity & Background**
- **Name:**
- **Aliases:**
- **Classification:**
- **Affiliation:**
- **Motivation:**
- **Target Preferences:**
- **Confidence in Attribution:**

Provide context on suspected origins, history, geopolitical ties, and any competing assessments across vendors.

---

## **Operational Profile**
### **Tactics, Techniques, and Procedures (TTPs)**
Use ATT&CK sections or link to T#### notes:
- **Tactics:**
- **Techniques:**
- **Procedures:**
> [!tip]- Tip!
> You can embed links to ATT&CK technique notes like `[[T1059 - Command Execution]]`.

---

## **Malware, Tools, and Infrastructure**
### **Malware / Tooling**
-

### **C2 & Infrastructure Patterns**
- VPS or hosting providers
- Domains and IP patterns
- Preferred protocols or frameworks (Cobalt Strike, Sliver, custom backdoors, etc.)

---

## **Campaigns & Activity History**
### **Major Campaigns**
- `[[Campaign Name]]`
- `[[Operation Example]]`

### **Timeline**
```chronos
- [2020] Event 1

- [2020-01-04~2020-01-14] Event 2

- [2020-01-10] Event 3

@ [2020-01-06~2020-01-10] Period 1
```

---

## **Indicators of Compromise**
Use this section for atomic observables or link to IOC notes.

### **IOCs**
- [[Hashes]]
- [[Domains]]
- [[IPs]]
- File Paths
- Registry Changes
- Delivery Mechanisms

---

## **Analyst Assessment**
Provide your analytic judgment here.

- **Threat Level:**
- **Assessment:**
- **Analytic Confidence:**
- **Implications for the Organization:**
- **Recommended PIRs:**
> [!tip]- Tip!
> It is recommended to use the Sherman-Kent scale and Words of Estimative Probability when scoring your analysis to ensure consistency with external sharing partners.

---

## **Hunting Guidance**

- High-fidelity detections
- Behavior-based hunts
- KQL / Sigma references
- Relevant telemetry sources (EDR, DNS, Firewall, Email logs, AD logs, etc.)

---

## **Sources**
Internal reports, external intelligence, vendor PDFs, links, and citations:

- 
- 

---

## **Change Log**
- *{{date}}:* Created 
- *{{date}}:* Updated